//
//  GJEllipseView.m
//  EllipseAnimationDemo
//
//  Created by v_guijiang on 2024/1/2.
//

#import "GJEllipseView.h"
#define scaleValue 0.70
#define scaleValueX 0.80
#define scaleHight 0.82 //667:812
#define ScreenWidth [UIScreen mainScreen].bounds.size.width
#define ScreenHeight [UIScreen mainScreen].bounds.size.height
@implementation GJEllipseView
CALayer* _layer;

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        
        _layer = [CALayer layer];
        
    }
    return self;
}


- (void)drawRect:(CGRect)rect {
    
//    if (_ellipticRect.size.width == 0){
        _ellipticRect = rect;
//    }
    [_layer removeFromSuperlayer];
//    _layer = [CALayer layer];
    CGRect aa = CGRectMake(_ellipticRect.origin.x-(_ellipticRect.size.height-_ellipticRect.size.width)/2, _ellipticRect.origin.y, _ellipticRect.size.height, _ellipticRect.size.height);
    _layer.frame = aa;
    _layer.backgroundColor = [UIColor clearColor].CGColor;
    _layer.masksToBounds = NO;
    
    UIBezierPath *arc = [UIBezierPath bezierPathWithOvalInRect:_ellipticRect];
   
    //圆环遮罩
    CAShapeLayer *shapeLayer = [CAShapeLayer layer];
    shapeLayer.fillColor = [UIColor clearColor].CGColor;
    shapeLayer.strokeColor = [UIColor whiteColor].CGColor;
    shapeLayer.lineWidth = 5;
    shapeLayer.strokeStart = 0;
    shapeLayer.strokeEnd = 1;
    shapeLayer.lineCap = kCALineCapRound;
    shapeLayer.lineDashPhase = 0.8;
    shapeLayer.path = arc.CGPath;
    shapeLayer.masksToBounds = NO;
    [_layer setMask:shapeLayer];
    
    [self.layer addSublayer:_layer];
//    [self.layer addSublayer:shapeLayer];
    
    
    CALayer *gradinetLayer = [CALayer layer];
    gradinetLayer.frame = CGRectMake(_ellipticRect.origin.x, 0, aa.size.height, aa.size.height);
    gradinetLayer.backgroundColor = [UIColor redColor].CGColor;
    gradinetLayer.masksToBounds = NO;
    [_layer addSublayer:gradinetLayer];
    
    
    CAGradientLayer *gradientLayerLeft = [CAGradientLayer layer];
    gradientLayerLeft.shadowPath = arc.CGPath;
    gradientLayerLeft.frame = CGRectMake(_ellipticRect.origin.x, 0, aa.size.height, aa.size.height/2);
    gradientLayerLeft.startPoint = CGPointMake(1, 0);
    gradientLayerLeft.endPoint = CGPointMake(0, 0);
    [gradientLayerLeft setColors:[NSArray arrayWithArray:_leftColors]];
    [gradinetLayer addSublayer:gradientLayerLeft];
    
    CAGradientLayer *gradientLayerRight = [CAGradientLayer layer];
    gradientLayerRight.shadowPath = arc.CGPath;
    gradientLayerRight.frame = CGRectMake(_ellipticRect.origin.x, aa.size.height/2, aa.size.height, aa.size.height/2);
    gradientLayerRight.startPoint = CGPointMake(0, 1);
    gradientLayerRight.endPoint = CGPointMake(1, 1);
    [gradientLayerRight setColors:[NSArray arrayWithArray:_rightColors]];
    [gradinetLayer addSublayer:gradientLayerRight];
    
    
    //    CGContextRestoreGState(context);
    CABasicAnimation *rotationAnimation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    rotationAnimation.fromValue = [NSNumber numberWithFloat:0];
    rotationAnimation.toValue = [NSNumber numberWithFloat:2.0*M_PI];
    rotationAnimation.repeatCount = MAXFLOAT;
    rotationAnimation.duration = 3;
    rotationAnimation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
//    [gradinetLayer addAnimation:rotationAnimation forKey:@"rotationAnnimation"];
    //
}
- (void)setLeftColors:(NSMutableArray *)leftColors{
    _leftColors = [leftColors copy];
    [self setNeedsDisplay];
}
- (void)setRightCOlors:(NSMutableArray *)rightColors{
    _rightColors = rightColors;
    [self setNeedsDisplay];
}
- (void)setEllipticRect:(CGRect)ellipticRect{
    _ellipticRect = ellipticRect;
    [self setNeedsDisplay];
}
@end

